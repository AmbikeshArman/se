
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

CREATE TABLE `admins` (
  `Id` int(4) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `admins` (`Id`, `Username`, `Password`) VALUES
(100, 'palak', 'abcdefgh');
-- --------------------------------------------------------


CREATE TABLE `cities` (
  `Name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `cities` (`Name`) VALUES
('Mumbai'),
('Delhi'),
('Bangalore'),
('Goa'),
('Pune'),
('Kolkata'),
('Allahabad'),
('Indore'),
('Ahmedabad'),
('Lucknow'),
('Agra'),
('Rajasthan');


CREATE TABLE `feedback` (
  `Name` text NOT NULL,
  `Contact` bigint(10) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `feedback` (`Name`, `Contact`, `Email`, `Message`) VALUES
('Palak Ahuja', 8858617161, 'polo210902@gmail.com', 'Can be improved');


CREATE TABLE `flights` (
  `Id` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Source` text NOT NULL,
  `Destination` text NOT NULL,
  `Departure` date NOT NULL,
  `Arrival` date NOT NULL,
  `Fair_Economic` int(11) NOT NULL,
  `Fair_Business` int(11) NOT NULL,
  `Available_seats` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `flights` (`Id`, `Name`, `Source`, `Destination`, `Departure`, `Arrival`, `Fair_Economic`, `Fair_Business`, `Available_seats`) VALUES
(101, 'AirIndia', 'Mumbai', 'Goa', '2022-05-05', '2022-05-06', 2700, 5000, 39),
(455, 'GoAir', 'Delhi', 'Indore', '2022-05-06', '2022-05-06', 5000, 8400, 47),
(1001, 'Emirates', 'Ahmedabad', 'Mumbai', '2022-05-06', '2022-05-06', 11700, 19000, 19),
(2120, 'Indigo', 'Lucknow', 'Rajasthan', '2022-05-06', '2022-05-06', 10000, 18000, 26);


CREATE TABLE `users` (
  `UserId` int(4) NOT NULL,
  `FirstName` text NOT NULL,
  `LastName` text NOT NULL,
  `MobileNo` bigint(10) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Flight_Id` int(11) NOT NULL,
  `Seats_booked` int(11) NOT NULL,
  `Total_Cost` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `users` (`UserId`, `FirstName`, `LastName`, `MobileNo`, `Email`, `Flight_Id`, `Seats_booked`, `Total_Cost`) VALUES
(101, 'Ambikesh', 'Arman', 123456789, 'ambikesharman@gmail.com', 1001, 1, 11700),
(102, 'Palak', 'Ahuja', 123456789, 'palakahuja@gmail.com', 101, 2, 5000),
(103, 'Sakshi', 'Tanwar', 123456789, 'sakshitanwar@gmail.com', 455, 1, 8400);


ALTER TABLE `admins`
  ADD PRIMARY KEY (`Id`);

ALTER TABLE `cities`
  ADD UNIQUE KEY `Name` (`Name`);

ALTER TABLE `flights`
  ADD UNIQUE KEY `Id` (`Id`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`UserId`),
  ADD KEY `Flight_Id` (`Flight_Id`);

ALTER TABLE `admins`
  MODIFY `Id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

ALTER TABLE `users`
  MODIFY `UserId` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`Flight_Id`) REFERENCES `flights` (`Id`) ON UPDATE CASCADE;
COMMIT;

