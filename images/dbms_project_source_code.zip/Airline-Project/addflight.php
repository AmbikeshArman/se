<<?php

include 'config.php';

$id = $_POST['id'];
$name = $_POST['name'];
$source = $_POST['source'];
$destination = $_POST['destination'];
$departure = $_POST['departure'];
$arrival = $_POST['arrival'];
$fair_economic = $_POST['Fair_Economic'];
$fair_business = $_POST['Fair_Business'];
$Available_seats = $_POST['Available_seats'];

$sql = "INSERT INTO flights(Id, Name, Source, Destination, Departure, Arrival, Fair_Economic, Fair_Business, Available_seats) VALUES ('$id', '$name', '$source', '$destination', '$departure', '$arrival', '$fair_economic', '$fair_business', '$Available_seats')";



if((!mysqli_query($conn,$sql))){//if the connection is made successfully and all the info of the flight is added to the db
  echo "Not Added!!!";
}
else {
  echo "Flight Added!!!";

}

$sql1 = "INSERT IGNORE INTO cities (Name) VALUES('$source')";//to ensure that there are no duplicates entered we used ignore keyword
$sql2 = "INSERT IGNORE INTO cities (Name) VALUES('$destination')";
mysqli_query($conn,$sql1);//checking if the connection is made as well as the source is inserted in the database
mysqli_query($conn,$sql2);//checking if the connection is made successfully and the destination is added in the db

header("Refresh:2; url=welcome.php");//sent a raw http code to redirect to welcome.php after 2s

mysqli_close($conn); //close the connection



 ?>
