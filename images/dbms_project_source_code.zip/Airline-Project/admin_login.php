<?php

include 'config.php';//included config.php to maintain a connection between the localhost server

if($_SERVER["REQUEST_METHOD"] == "POST") {//obviously we are using post request method...plus as the password n all are included hm post request hi use krenge
   // username and password sent from form

   $username = $_POST['username'];//username ko ek variable me store krdia
   $password = $_POST['password'];//password that the user 

   $sql = "SELECT Id FROM admins WHERE Username = '$username' and Password = '$password'";//sql query to select that admin
   $result = mysqli_query($conn,$sql);//if any such admin is found
   $row = mysqli_fetch_array($result,MYSQLI_ASSOC);//to fetch that row..
   $count = mysqli_num_rows($result);//if there's exactly one row 

   // If result matched $myusername and $mypassword, table row must be 1 row

   if($count == 1) {
      $_SESSION["myusername"]=$username; //setting the session variables
      $_SESSION['login_user'] = $username;
    

      header("location: welcome.php");//set krne k bad wpas se welcome.php page pr
   }else {
      $error = "Your Login Name or Password is invalid<br><br>";//else if there's an invalid login with the wrong credentials
      echo $error; //we'll just print the error on the page



   }
}

mysqli_close($conn); //rthen close the connection

 ?>
